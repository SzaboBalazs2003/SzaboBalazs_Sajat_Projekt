﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Sajat_Projekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        char[,] allas = new char[8, 8];
        bool egykat = false, feher = true, fekete = false, utes = false;
        int m, n;
        private void dama_Click(object sender, RoutedEventArgs e)
        {
            Beolvas();
            Tabla();
            Betolt();
            dama.IsHitTestVisible = false;
            dama.Visibility = Visibility.Hidden;
        }
        private void Tabla()
        {
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    Label temp = new Label();
                    Thickness margo = new Thickness(5, 5, 5, 5);
                    if ((j % 2 == 0 && i % 2 == 1))
                    {
                        temp.Background = new SolidColorBrush(Color.FromRgb(0, 0, 0));


                    }
                    else if (j % 2 == 1 && i % 2 == 0)
                    {
                        temp.Background = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                    }
                    Grid.SetRow(temp, i);
                    Grid.SetColumn(temp, j);
                    Also.Children.Add(temp);
                }
            }

        }
        private void Beolvas()
        {
            string[] kezd = File.ReadAllLines("allas.txt");
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    string sor = kezd[i];
                    allas[i, j] = sor[j];
                }
            }
        }
        private void Betolt()
        {
            Felso.Children.Clear();
            if (feher)
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (allas[i, j] == 'W')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            kep.UriSource = new Uri(@"/White_piece.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            for (int n = 1; n < 13; n++)
                            {
                                temp.Name = "W" + Convert.ToString(n);
                            }
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'B')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            kep.UriSource = new Uri(@"/Black_piece.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            for (int n = 1; n < 13; n++)
                            {
                                temp.Name = "B" + Convert.ToString(n);
                            }
                            temp.IsHitTestVisible = false;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i,j] == 'w')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            kep.UriSource = new Uri(@"/White_piece2.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i,j] == 'b')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            kep.UriSource = new Uri(@"/Black_piece2.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            temp.IsHitTestVisible = false;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == '#')
                        {
                            Image temp = new Image();
                            temp.Opacity = 0;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'L')
                        {
                            Image temp = new Image();
                            temp.Width = 80;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            kep.UriSource = new Uri(@"/lephet.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown2;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                    }
                }
            }
            else if (fekete)
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (allas[i, j] == 'W')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            //kep.UriSource = new Uri(@"pack://application:,,,/pictures/White_piece.png");
                            kep.UriSource = new Uri(@"/White_piece.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            for (int n = 1; n < 13; n++)
                            {
                                temp.Name = "W" + Convert.ToString(n);
                            }
                            temp.IsHitTestVisible = false;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'B')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            //kep.UriSource = new Uri(@"pack://application:,,,/pictures/White_piece.png");
                            kep.UriSource = new Uri(@"/Black_piece.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            for (int n = 1; n < 13; n++)
                            {
                                temp.Name = "B" + Convert.ToString(n);
                            }
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'w')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            //kep.UriSource = new Uri(@"pack://application:,,,/pictures/White_piece.png");
                            kep.UriSource = new Uri(@"/White_piece2.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            IsHitTestVisible = false;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'b')
                        {
                            Thickness margo = new Thickness(2, 2, 2, 2);
                            Image temp = new Image();
                            temp.Width = 80;
                            temp.Margin = margo;

                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            //kep.UriSource = new Uri(@"pack://application:,,,/pictures/White_piece.png");
                            kep.UriSource = new Uri(@"/Black_piece2.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == '#')
                        {
                            Image temp = new Image();
                            temp.Opacity = 0;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                        else if (allas[i, j] == 'L')
                        {
                            Image temp = new Image();
                            temp.Width = 80;
                            BitmapImage kep = new BitmapImage();
                            kep.BeginInit();
                            //kep.UriSource = new Uri(@"pack://application:,,,/pictures/White_piece.png");
                            kep.UriSource = new Uri(@"/lephet.png", UriKind.Relative);
                            kep.DecodePixelWidth = 80;
                            kep.EndInit();
                            temp.Source = kep;
                            temp.MouseLeftButtonDown += Image_MouseLeftButtonDown2;
                            Grid.SetRow(temp, i);
                            Grid.SetColumn(temp, j);
                            Felso.Children.Add(temp);
                        }
                    }
                }
            }

        }
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
            if (egykat)
            {
                Image ezbabu = sender as Image;
                int index = Felso.Children.IndexOf(ezbabu);
                m = index / 8;
                n = index % 8;
                if (allas[m, n] == 'W')
                {
                    if (m - 1 > -1 && n - 1 > -1)
                    {
                        if (allas[m - 1, n - 1] == '#')
                        {
                            allas[m - 1, n - 1] = 'L';
                        }
                        else if (m - 2 > -1 && n - 2 > -1)
                        {
                            if (allas[m - 1, n - 1] == 'B' || allas[m - 1, n - 1] == 'b')
                            {
                                if (allas[m - 2, n - 2] == '#')
                                {
                                    allas[m - 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m - 1 > -1 && n + 1 < 8)
                    {
                        if (allas[m - 1, n + 1] == '#')
                        {
                            allas[m - 1, n + 1] = 'L';
                        }
                        else if (m - 2 > -1 && n + 2 < 8)
                        {
                            if (allas[m - 1, n + 1] == 'B' || allas[m - 1, n + 1] == 'b')
                            {
                                if (allas[m - 2, n + 2] == '#')
                                {
                                    allas[m - 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                }
                else if (allas[m, n] == 'B')
                {
                    if (m + 1 < 8 && n + 1 < 8)
                    {
                        if (allas[m + 1, n + 1] == '#')
                        {
                            allas[m + 1, n + 1] = 'L';
                        }
                        else if (m + 2 < 8 && n + 2 < 8)
                        {
                            if (allas[m + 1, n + 1] == 'W' || allas[m + 1, n + 1] == 'w')
                            {
                                if (allas[m + 2, n + 2] == '#')
                                {
                                    allas[m + 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m + 1 < 8 && n - 1 > -1)
                    {
                        if (allas[m + 1, n - 1] == '#')
                        {
                            allas[m + 1, n - 1] = 'L';
                        }
                        else if (m + 2 < 8 && n - 2 > -1)
                        {
                            if (allas[m + 1, n - 1] == 'W' || allas[m + 1, n - 1] == 'w')
                            {
                                if (allas[m + 2, n - 2] == '#')
                                {
                                    allas[m + 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                }
                else if (allas[m, n] == 'b')
                {
                    if (m - 1 > -1 && n - 1 > -1)
                    {
                        if (allas[m - 1, n - 1] == '#')
                        {
                            allas[m - 1, n - 1] = 'L';
                        }
                        else if (m - 2 > -1 && n - 2 > -1)
                        {
                            if (allas[m - 1, n - 1] == 'W' || allas[m - 1, n - 1] == 'w')
                            {
                                if (allas[m - 2, n - 2] == '#')
                                {
                                    allas[m - 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m - 1 > -1 && n + 1 < 8)
                    {
                        if (allas[m - 1, n + 1] == '#')
                        {
                            allas[m - 1, n + 1] = 'L';
                        }
                        else if (m - 2 > -1 && n + 2 < 8)
                        {
                            if (allas[m - 1, n + 1] == 'W' || allas[m - 1, n + 1] == 'w')
                            {
                                if (allas[m - 2, n + 2] == '#')
                                {
                                    allas[m - 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m + 1 < 8 && n + 1 < 8)
                    {
                        if (allas[m + 1, n + 1] == '#')
                        {
                            allas[m + 1, n + 1] = 'L';
                        }
                        else if (m + 2 < 8 && n + 2 < 8)
                        {
                            if (allas[m + 1, n + 1] == 'W' || allas[m + 1, n + 1] == 'w')
                            {
                                if (allas[m + 2, n + 2] == '#')
                                {
                                    allas[m + 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m + 1 < 8 && n - 1 > -1)
                    {
                        if (allas[m + 1, n - 1] == '#')
                        {
                            allas[m + 1, n - 1] = 'L';
                        }
                        else if (m + 2 < 8 && n - 2 > -1)
                        {
                            if (allas[m + 1, n - 1] == 'W' || allas[m + 1, n - 1] == 'w')
                            {
                                if (allas[m + 2, n - 2] == '#')
                                {
                                    allas[m + 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                }
                else if (allas[m, n] == 'w')
                {
                    if (m - 1 > -1 && n - 1 > -1)
                    {
                        if (allas[m - 1, n - 1] == '#')
                        {
                            allas[m - 1, n - 1] = 'L';
                        }
                        else if (m - 2 > -1 && n - 2 > -1)
                        {
                            if (allas[m - 1, n - 1] == 'B' || allas[m - 1, n - 1] == 'b')
                            {
                                if (allas[m - 2, n - 2] == '#')
                                {
                                    allas[m - 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m - 1 > -1 && n + 1 < 8)
                    {
                        if (allas[m - 1, n + 1] == '#')
                        {
                            allas[m - 1, n + 1] = 'L';
                        }
                        else if (m - 2 > -1 && n + 2 < 8)
                        {
                            if (allas[m - 1, n + 1] == 'B' || allas[m - 1, n + 1] == 'b')
                            {
                                if (allas[m - 2, n + 2] == '#')
                                {
                                    allas[m - 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m + 1 < 8 && n + 1 < 8)
                    {
                        if (allas[m + 1, n + 1] == '#')
                        {
                            allas[m + 1, n + 1] = 'L';
                        }
                        else if (m + 2 < 8 && n + 2 < 8)
                        {
                            if (allas[m + 1, n + 1] == 'B' || allas[m + 1, n + 1] == 'b')
                            {
                                if (allas[m + 2, n + 2] == '#')
                                {
                                    allas[m + 2, n + 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                    if (m + 1 < 8 && n - 1 > -1)
                    {
                        if (allas[m + 1, n - 1] == '#')
                        {
                            allas[m + 1, n - 1] = 'L';
                        }
                        else if (m + 2 < 8 && n - 2 > -1)
                        {
                            if (allas[m + 1, n - 1] == 'B' || allas[m + 1, n - 1] == 'b')
                            {
                                if (allas[m + 2, n - 2] == '#')
                                {
                                    allas[m + 2, n - 2] = 'L';
                                    utes = true;
                                }
                            }
                        }
                    }
                }
                egykat = false;
            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (allas[i,j] == 'L')
                        {
                            allas[i, j] = '#';
                        }
                    }
                }
                egykat = true;
            }
            Betolt();
        }
        private void Image_MouseLeftButtonDown2(object sender, MouseButtonEventArgs e)
        {
            Image ezbabu = sender as Image;
            int index = Felso.Children.IndexOf(ezbabu);
            int i, j;
            i = index / 8;
            j = index % 8;
            if (feher)
            {
                if (!utes)
                {
                    if (allas[m, n] == 'W')
                    {
                        allas[i, j] = 'W';
                        allas[m, n] = '#';
                        feher = false;
                        fekete = true;
                    }
                    else if (allas[m, n] == 'w')
                    {
                        allas[i, j] = 'w';
                        allas[m, n] = '#';
                        feher = false;
                        fekete = true;
                    }

                }
                else if (utes)
                {
                    if (allas[m, n] == 'W')
                    {
                        if (i + 2 == m && j+2==n)
                        {
                            allas[i, j] = 'W';
                            allas[m, n] = '#';
                            allas[m-1, n-1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        if ((i + 2 == m && j - 2 == n))
                        {
                            allas[i, j] = 'W';
                            allas[m, n] = '#';
                            allas[m-1, n+1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if ((i + 1 == m && j+1 == n) || (i+1 == m && j-1 == n))
                        {
                            allas[i, j] = 'W';
                            allas[m, n] = '#';
                            feher = false;
                            fekete = true;
                        }
                    }
                    else if (allas[m, n] == 'w')
                    {
                        if (i - 2 == m && j + 2 == n)
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            allas[m+1, n-1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        if (i - 2 == m && j - 2 == n)
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            allas[m+1, n+1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if (i + 2 == m && j + 2 == n)
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            allas[m-1, n-1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if (i + 2 == m && j - 2 == n)
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            allas[m-1, n+1] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if ((i + 1 == m && j + 1 == n) || (i + 1 == m && j - 1 == n))
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if ((i - 1 == m && j + 1 == n) || (i - 1 == m && j - 1 == n))
                        {
                            allas[i, j] = 'w';
                            allas[m, n] = '#';
                            feher = false;
                            fekete = true;
                        }
                    }
                }
                feher = false;
                fekete = true;
            }
            else if (fekete)
            {
                if (!utes)
                {
                    if (allas[m, n] == 'B')
                    {
                        allas[i, j] = 'B';
                        allas[m, n] = '#';
                        feher = true;
                        fekete = false;
                    }
                    else if (allas[m, n] == 'b')
                    {
                        allas[i, j] = 'b';
                        allas[m, n] = '#';
                        feher = true;
                        fekete = false;
                    }
                }
                else if (utes)
                {
                    if (allas[m, n] == 'B')
                    {
                        if (i - 2 == m && j + 2 == n)
                        {
                            allas[i, j] = 'B';
                            allas[m, n] = '#';
                            allas[m+1, n-1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if (i - 2 == m && j - 2 == n)
                        {
                            allas[i, j] = 'B';
                            allas[m, n] = '#';
                            allas[m + 1, n + 1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if ((i - 1 == m && j + 1 == n) || (i - 1 == m && j - 1 == n))
                        {
                            allas[i, j] = 'B';
                            allas[m, n] = '#';
                            feher = true;
                            fekete = false;
                        }
                    }
                    else if (allas[m, n] == 'b')
                    {
                        if (i - 2 == m && j + 2 == n)
                        {
                            allas[i, j] = 'b';
                            allas[m, n] = '#';
                            allas[m + 1, n - 1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if (i - 2 == m && j - 2 == n)
                        {
                            allas[i, j] = 'b';
                            allas[m, n] = '#';
                            allas[m + 1, n + 1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if (i + 2 == m && j + 2 == n)
                        {
                            allas[i, j] = 'b';
                            allas[m, n] = '#';
                            allas[m - 1, n - 1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if ((i + 2 == m && j - 2 == n))
                        {
                            allas[i, j] = 'b';
                            allas[m, n] = '#';
                            allas[m - 1, n + 1] = '#';
                            feher = true;
                            fekete = false;
                        }
                        else if ((i + 1 == m && j + 1 == n) || (i + 1 == m && j - 1 == n))
                        {
                            allas[i, j] = 'b';
                            allas[m, n] = '#';
                            feher = false;
                            fekete = true;
                        }
                        else if ((i - 1 == m && j + 1 == n) || (i - 1 == m && j - 1 == n))
                        {
                            allas[i, j] = 'B';
                            allas[m, n] = '#';
                            feher = true;
                            fekete = false;
                        }
                    }
                }
                feher = true;
                fekete = false;
            }
            for (int a = 0; a < 8; a++)
            {
                if (allas[0,a] == 'W')
                {
                    allas[0, a] = 'w';
                }
                if (allas[7,a] == 'B')
                {
                    allas[7, a] = 'b';
                }
            }
            for (int a = 0; a < 8; a++)
            {
                for (int b = 0; b < 8; b++)
                {
                    if (allas[a, b] == 'L')
                    {
                        allas[a, b] = '#';
                    }
                }
            }
            Betolt();
            Ellenorzes();
        }
        private void Ellenorzes()
        {
            StringBuilder egesz = new StringBuilder();
            foreach (var item in allas)
            {
                egesz.Append(Convert.ToString(item));
            }
            string kesz = egesz.ToString();
            if (!(kesz.Contains('B') || kesz.Contains('b')))
            {
                MessageBox.Show("Játék vége. \n A fehér játékos nyert!");
                Felso.Children.Clear();
                Also.Children.Clear();
                dama.Visibility = Visibility.Visible;
                dama.IsHitTestVisible = true;
            }
            if (!(kesz.Contains('W') || kesz.Contains('w')))
            {
                MessageBox.Show("Játék vége. \n A fekete játékos nyert!");
                Felso.Children.Clear();
                Also.Children.Clear();
                dama.Visibility = Visibility.Visible;
                dama.IsHitTestVisible = true;
            }
            Felso.IsHitTestVisible = true;
            egesz.Clear();
        }
    }
}
