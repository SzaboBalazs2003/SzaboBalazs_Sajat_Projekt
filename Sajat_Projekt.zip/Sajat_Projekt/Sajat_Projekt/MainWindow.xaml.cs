﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Sajat_Projekt
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void dama_Click(object sender, RoutedEventArgs e)
        {
            char[] oszlop = {'A','B','C','D','E','F','G','H' };
            char[] sor = { '8','7','6','5','4','3','2','1' };
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    Label temp = new Label();
                    Thickness margo = new Thickness(5, 5, 5, 5);
                    temp.Name = $"{oszlop[j]}{sor[i]}";
                    //temp.Content = $"{oszlop[j]}{sor[i]}";
                    //temp.Margin = margo;
                    if ((j%2==0 && i%2==1))
                    {
                        temp.Background = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                        
                        
                    }
                    else if (j%2==1 && i%2==0)
                    {
                        temp.Background = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                    }
                    Grid.SetRow(temp, i);
                    Grid.SetColumn(temp, j);
                    Tabla.Children.Add(temp);
                    //Tabla.Margin = margo;
                }
            }
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    if ((j % 2 == 0 && i % 2 == 1))
                    {
                        //Tabla.
                    }
                    else if (j % 2 == 1 && i % 2 == 0)
                    {
                        //temp.Background = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                    }
                }
            }
            dama.IsHitTestVisible = false;
            dama.Visibility = Visibility.Hidden;
        }
    }
}
